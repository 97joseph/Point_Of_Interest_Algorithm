input_size_local = [80,80]
input_size_global = [50, 50] 